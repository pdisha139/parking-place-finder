import Button from './Button';

const AuthOptions = () => {
	return (
		<div className = 'authoptions'>
			<Button text = 'Log in' />
			<Button text = 'Sign up' />
		</div>
	);
};

export default AuthOptions;