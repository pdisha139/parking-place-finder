import Bookings from '../components/Profile/Bookings';

const BookingsPage = () => {
	return <Bookings />
};

export default BookingsPage;