import Navbar1 from '../components/Layout/Navbar1';
import HeroAuth from '../components/Layout/HeroAuth';

const AuthPage = () => {
  return (
    <>
      <Navbar1 />
      <HeroAuth />
    </>
  );
};

export default AuthPage;
