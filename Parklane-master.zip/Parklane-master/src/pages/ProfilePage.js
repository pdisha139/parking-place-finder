import ParkHere from '../components/Profile/ParkHere';

const ProfilePage = () => {
  return <ParkHere />;
};

export default ProfilePage;
